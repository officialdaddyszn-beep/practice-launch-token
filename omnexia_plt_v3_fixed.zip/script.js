document.addEventListener('DOMContentLoaded', () => {
  const menuButton = document.querySelector('.nav-menu');
  const header = document.querySelector('header');
  const nav = document.querySelector('.site-nav nav');

  if (menuButton && header && nav) {
    menuButton.setAttribute('aria-expanded', 'false');

    const closeMenu = () => {
      header.classList.remove('mobile-open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Open menu');
    };

    const toggleMenu = (event) => {
      event.preventDefault();
      event.stopPropagation();
      const isOpen = header.classList.toggle('mobile-open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
      menuButton.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
    };

    menuButton.addEventListener('click', toggleMenu);

    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', closeMenu);
    });

    document.addEventListener('click', event => {
      if (!header.contains(event.target)) closeMenu();
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 800) closeMenu();
    });
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('show');
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('.reveal').forEach(element => observer.observe(element));
});
